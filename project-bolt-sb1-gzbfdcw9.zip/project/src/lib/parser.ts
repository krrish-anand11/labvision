import type { ScenarioType } from './physics';
import { G_PRESETS } from './physics';

export interface Extracted {
  velocity?: number;
  angle?: number;
  mass?: number;
  gravity?: number;
  length?: number;
}

export interface ParseResult {
  scenario: ScenarioType | null;
  extracted: Extracted;
  matched: string[];
}

const NUM = '(\\d+(?:\\.\\d+)?)';

const SCENARIO_KEYWORDS: Array<{ scenario: ScenarioType; re: RegExp; label: string }> = [
  { scenario: 'pendulum', re: /\b(pendulum|bob|grandfather\s+clock|clock|swing|swings|swinging|string)\b/i, label: 'pendulum keywords' },
  { scenario: 'incline', re: /\b(incline[ds]?|inclined|ramp|slope|ski|hill|wedge|slide|slides|sliding)\b/i, label: 'ramp keywords' },
  { scenario: 'projectile', re: /\b(launch|launched|launches|projectile|cannon|cannonball|thrown|throw|kicked|fired|shot|javelin|arrow|ball)\b/i, label: 'projectile keywords' },
];

function firstMatch(text: string, re: RegExp): number | undefined {
  const m = text.match(re);
  if (!m) return undefined;
  const v = parseFloat(m[1]);
  return Number.isFinite(v) ? v : undefined;
}

export function parseProblem(text: string): ParseResult {
  const extracted: Extracted = {};
  const matched: string[] = [];

  let scenario: ScenarioType | null = null;
  for (const k of SCENARIO_KEYWORDS) {
    if (k.re.test(text)) {
      scenario = k.scenario;
      matched.push(k.label);
      break;
    }
  }

  const velocity = firstMatch(text, new RegExp(`${NUM}\\s*(?:m\\s*\\/\\s*s|m\\/s|met(?:er|re)s?\\s+per\\s+second)`, 'i'));
  if (velocity !== undefined) {
    extracted.velocity = velocity;
    matched.push('velocity');
  }

  const angle = firstMatch(text, new RegExp(`${NUM}\\s*(?:°|degrees?|degs?)`, 'i'));
  if (angle !== undefined) {
    extracted.angle = angle;
    matched.push('angle');
  }

  const mass = firstMatch(text, new RegExp(`${NUM}\\s*(?:kg|kilograms?)`, 'i'));
  if (mass !== undefined) {
    extracted.mass = mass;
    matched.push('mass');
  }

  const length = firstMatch(text, new RegExp(`${NUM}\\s*m(?!\\s*\\/)(?!\\s*s\\b)`, 'i'));
  if (length !== undefined) {
    extracted.length = length;
    matched.push('length');
  }

  if (/\bmoon\b/i.test(text)) {
    extracted.gravity = G_PRESETS.Moon;
    matched.push('Moon gravity');
  } else if (/\bmars\b/i.test(text)) {
    extracted.gravity = G_PRESETS.Mars;
    matched.push('Mars gravity');
  } else if (/\bearth\b/i.test(text)) {
    extracted.gravity = G_PRESETS.Earth;
    matched.push('Earth gravity');
  }

  if (scenario === null && extracted.velocity !== undefined && extracted.angle !== undefined) {
    scenario = 'projectile';
    matched.push('fallback: velocity + angle');
  }

  return { scenario, extracted, matched };
}
