export type ScenarioType = 'projectile' | 'incline' | 'pendulum';

export interface Params {
  velocity: number; // m/s
  angle: number; // degrees
  mass: number; // kg
  gravity: number; // m/s^2
  length: number; // m (ramp length or pendulum length)
}

export const G_PRESETS = {
  Earth: 9.81,
  Moon: 1.62,
  Mars: 3.72,
} as const;

export const DEFAULT_PARAMS: Params = {
  velocity: 25,
  angle: 40,
  mass: 5,
  gravity: 9.81,
  length: 15,
};

export interface SimState {
  t: number;
  // projectile
  x: number;
  y: number;
  vx: number;
  vy: number;
  // incline
  s: number; // distance traveled along ramp
  sv: number; // speed along ramp
  // pendulum
  theta: number; // radians from vertical
  omega: number; // rad/s
}

const DEG = Math.PI / 180;

export function createSimState(p: Params, scenario: ScenarioType): SimState {
  const th = p.angle * DEG;
  return {
    t: 0,
    x: 0,
    y: 0,
    vx: p.velocity * Math.cos(th),
    vy: p.velocity * Math.sin(th),
    s: 0,
    sv: 0,
    theta: scenario === 'pendulum' ? th : 0,
    omega: 0,
  };
}

export function advance(s: SimState, dt: number, p: Params, scenario: ScenarioType): SimState {
  if (scenario === 'projectile') {
    s.t += dt;
    const th = p.angle * DEG;
    s.vx = p.velocity * Math.cos(th);
    s.vy = p.velocity * Math.sin(th);
    s.x = s.vx * s.t;
    s.y = Math.max(0, s.vy * s.t - 0.5 * p.gravity * s.t * s.t);
  } else if (scenario === 'incline') {
    s.t += dt;
    const a = p.gravity * Math.sin(p.angle * DEG);
    s.s = Math.min(p.length, 0.5 * a * s.t * s.t);
    s.sv = a * s.t;
  } else {
    // Pendulum: RK4 integration of theta'' = -(g/L) sin(theta)
    const steps = Math.max(1, Math.ceil(dt / (1 / 240)));
    const h = dt / steps;
    for (let i = 0; i < steps; i++) {
      const acc = (th: number) => -(p.gravity / p.length) * Math.sin(th);
      const { theta, omega } = s;
      const k1th = omega;
      const k1om = acc(theta);
      const k2th = omega + (h / 2) * k1om;
      const k2om = acc(theta + (h / 2) * k1th);
      const k3th = omega + (h / 2) * k2om;
      const k3om = acc(theta + (h / 2) * k2th);
      const k4th = omega + h * k3om;
      const k4om = acc(theta + h * k3th);
      s.theta += (h / 6) * (k1th + 2 * k2th + 2 * k3th + k4th);
      s.omega += (h / 6) * (k1om + 2 * k2om + 2 * k3om + k4om);
    }
    s.t += dt;
  }
  return s;
}

export interface Kinematics {
  x: number;
  y: number;
  vx: number;
  vy: number;
  speed: number;
}

export function getKinematics(s: SimState, p: Params, scenario: ScenarioType): Kinematics {
  if (scenario === 'projectile') {
    const vy = p.velocity * Math.sin(p.angle * DEG) - p.gravity * s.t;
    return { x: s.x, y: s.y, vx: s.vx, vy, speed: Math.hypot(s.vx, vy) };
  }
  if (scenario === 'incline') {
    const th = p.angle * DEG;
    const topX = p.length * Math.cos(th);
    const topY = p.length * Math.sin(th);
    return {
      x: topX - s.s * Math.cos(th),
      y: topY - s.s * Math.sin(th),
      vx: -s.sv * Math.cos(th),
      vy: -s.sv * Math.sin(th),
      speed: s.sv,
    };
  }
  const { theta, omega } = s;
  return {
    x: p.length * Math.sin(theta),
    y: -p.length * Math.cos(theta),
    vx: omega * p.length * Math.cos(theta),
    vy: omega * p.length * Math.sin(theta),
    speed: Math.abs(omega) * p.length,
  };
}

export function isDone(s: SimState, p: Params, scenario: ScenarioType): boolean {
  if (scenario === 'projectile') {
    const flight = (2 * p.velocity * Math.sin(p.angle * DEG)) / p.gravity;
    return s.t >= flight;
  }
  if (scenario === 'incline') return s.s >= p.length - 1e-9;
  return false;
}

export interface ProjectileResults {
  vx: number;
  vy: number;
  flightTime: number;
  maxHeight: number;
  range: number;
}

export function projectileResults(p: Params): ProjectileResults {
  const th = p.angle * DEG;
  const vx = p.velocity * Math.cos(th);
  const vy = p.velocity * Math.sin(th);
  const flightTime = (2 * vy) / p.gravity;
  return {
    vx,
    vy,
    flightTime,
    maxHeight: (vy * vy) / (2 * p.gravity),
    range: vx * flightTime,
  };
}

export interface InclineResults {
  accel: number;
  timeToBottom: number;
  finalSpeed: number;
}

export function inclineResults(p: Params): InclineResults {
  const a = p.gravity * Math.sin(p.angle * DEG);
  return {
    accel: a,
    timeToBottom: Math.sqrt((2 * p.length) / a),
    finalSpeed: Math.sqrt(2 * a * p.length),
  };
}

export interface PendulumResults {
  period: number;
  frequency: number;
}

export function pendulumResults(p: Params): PendulumResults {
  const period = 2 * Math.PI * Math.sqrt(p.length / p.gravity);
  return { period, frequency: 1 / period };
}

export function formatNum(n: number, digits = 2): string {
  if (!Number.isFinite(n)) return '—';
  return n.toFixed(digits);
}
